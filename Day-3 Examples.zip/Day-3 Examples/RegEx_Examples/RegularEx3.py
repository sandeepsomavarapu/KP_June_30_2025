import re

matcher=re.finditer("\W","a7b@k 9Z$7_wQ%") #[abc]
for match in matcher:
    # print(match)
    print(match.start(),"...",match.group())